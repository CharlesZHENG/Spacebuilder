﻿////<TunynetCopyright>
////--------------------------------------------------------------
////<copyright>tunynet inc. 2005-2013</copyright>
////<version>V0.5</verion>
////<createdate>2010-10-17</createdate>
////<author>mazq</author>
////<email>mazq@tunynet.com</email>
////<log date="2010-10-17" version="0.5">创建</log>
////--------------------------------------------------------------
////</TunynetCopyright>

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace Spacebuilder.CMS.Search
//{
//    /// <summary>
//    /// 搜索结果项
//    /// </summary>
//    public interface ISearchHit
//    {
//        int ContentItemId { get; }
//        float Score { get; }

//        int GetInt(string fieldName);
//        decimal GetDecimal(string fieldName);
//        bool GetBoolean(string fieldName);
//        string GetString(string fieldName);
//        DateTime GetDateTime(string fieldName);
//    }
//}
