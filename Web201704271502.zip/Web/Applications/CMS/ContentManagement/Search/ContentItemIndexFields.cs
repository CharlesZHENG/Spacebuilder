﻿////<TunynetCopyright>
////--------------------------------------------------------------
////<copyright>tunynet inc. 2005-2013</copyright>
////<version>V0.5</verion>
////<createdate>2010-10-17</createdate>
////<author>mazq</author>
////<email>mazq@tunynet.com</email>
////<log date="2010-10-17" version="0.5">创建</log>
////--------------------------------------------------------------
////</TunynetCopyright>

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace Spacebuilder.CMS.Search
//{
//    /// <summary>
//    /// Content索引字段
//    /// </summary>
//    public static class ContentItemIndexFields
//    {

//        public static string ContentItemId = "ContentItemId";

//        public static string ContentFolderId = "ContentFolderId";

//        public static string ContentTypeId = "ContentTypeId";

//        public static string Title = "Title";

//        public static string UserId = "UserId";

//        public static string Author = "Author";

//        public static string IsEssential = "IsEssential";

//        public static string IsSticky = "IsSticky";

//        public static string DateCreated = "DateCreated";

//        public static string LastModified = "LastModified";

//    }
//}
