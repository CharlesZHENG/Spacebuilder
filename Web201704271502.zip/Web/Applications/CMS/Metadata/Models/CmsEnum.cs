﻿//------------------------------------------------------------------------------
// <copyright company="Tunynet">
//     Copyright (c) Tunynet Inc.  All rights reserved.
// </copyright> 
//------------------------------------------------------------------------------

using System.ComponentModel.DataAnnotations;

namespace Spacebuilder.CMS
{
    /// <summary>
    /// 问题排序依据
    /// </summary>
    //public enum PageType
    //{ 
    //   /// <summary>
    //   /// 不分页
    //   /// </summary>
    //   [Display(Name = "不分页")]
    //    NoPage=0,
    //    /// <summary>
    //    /// 自动分页
    //    /// </summary>
    //    [Display(Name = "自动分页")]
    //    AutoPage=1,
    //   /// <summary>
    //   /// 手动分页
    //   /// </summary>
    //  [Display(Name = "手动分页")]
    //    ManualPage=2
    //}

   
   
}