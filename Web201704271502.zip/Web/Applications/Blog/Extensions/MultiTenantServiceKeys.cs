﻿//<TunynetCopyright>
//--------------------------------------------------------------
//<version>V0.5</verion>
//<createdate>2012-11-01</createdate>
//<author>libsh</author>
//<email>libsh@tunynet.com</email>
//<log date="2012-11-01" version="0.5">创建</log>
//--------------------------------------------------------------
//</TunynetCopyright>

using Tunynet.Common;

namespace Spacebuilder.Blog
{
    /// <summary>
    /// 日志定义的ServiceKey
    /// </summary>
    public static class MultiTenantServiceKeysExtension
    {

        ///// <summary>
        ///// 日志ServiceKey
        ///// </summary>
        //public static string Blog(this MultiTenantServiceKeys multiTenantServiceKeys)
        //{
        //    return "Blog";
        //}


    }
}